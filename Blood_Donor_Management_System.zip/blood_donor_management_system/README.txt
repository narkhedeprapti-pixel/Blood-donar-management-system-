BLOOD DONOR MANAGEMENT SYSTEM
================================

Technology:
- HTML
- CSS
- JavaScript
- PHP
- MySQL
- XAMPP

PROJECT MODULES
---------------
1. Home page
2. Donor registration
3. View all registered donors
4. Search donors by blood group and city

FOLDER CONTENTS
---------------
index.php       Home page
register.php    Donor registration form
view.php        Display registered donors
search.php      Search donors by blood group and city
db.php          MySQL database connection
style.css       Website design
script.js       Client-side form validation
database.sql    Database and table creation script

XAMPP SETUP INSTRUCTIONS
------------------------
1. Install and open XAMPP.
2. Start Apache and MySQL.
3. Copy the complete "blood_donor_management_system" folder into:
   C:\\xampp\\htdocs\\
4. Open this address in your browser:
   http://localhost/phpmyadmin
5. Click the Import tab.
6. Choose database.sql from this project folder.
7. Click Import / Go.
8. Open the project:
   http://localhost/blood_donor_management_system/

DATABASE SETTINGS
-----------------
Host: localhost
Username: root
Password: (blank by default in XAMPP)
Database: bloodbank

If your MySQL root account has a password, update db.php accordingly.

HOW TO TEST
-----------
1. Open the home page.
2. Click "Become a Donor" and submit the registration form.
3. Open "View Donors" to see saved records.
4. Open "Search Donor", select a blood group, and optionally enter a city.
5. Try searching for A+ in Pune (sample data is included).

IMPORTANT NOTES
---------------
- This is an educational mini project, not a real blood-bank service.
- Sample records are fictional and for testing only.
- Donor contact details are visible in the directory. Use only with
  informed consent; do not publish real personal data without permission.
- Age validation in this demo is a basic form check, not medical clearance.
- Before public deployment, add authentication, authorization, stronger
  privacy controls, CSRF protection, and further server-side validation.
