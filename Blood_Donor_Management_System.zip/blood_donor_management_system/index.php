<?php
include "db.php";
$totalResult = $conn->query("SELECT COUNT(*) AS total FROM donors");
$total = $totalResult ? $totalResult->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donor Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="index.php">❤️ BloodConnect</a>
    <nav>
        <a href="index.php">Home</a>
        <a href="register.php">Register</a>
        <a href="view.php">View Donors</a>
        <a href="search.php">Search Donor</a>
    </nav>
</header>

<main>
    <section class="hero">
        <div class="hero-content">
            <p class="eyebrow">GIVE BLOOD · SAVE LIVES</p>
            <h1>Every drop makes<br><span>a difference.</span></h1>
            <p class="hero-text">Connect blood donors with people who need help. Register as a donor or find a donor by blood group.</p>
            <div class="actions">
                <a class="btn" href="register.php">Become a Donor</a>
                <a class="btn btn-outline" href="search.php">Find a Donor</a>
            </div>
        </div>
        <div class="hero-card">
            <div class="drop">♥</div>
            <h2>Be someone's hero</h2>
            <p>One donation can help save lives.</p>
            <div class="stat"><strong><?php echo (int)$total; ?></strong><span>Registered donors</span></div>
        </div>
    </section>

    <section class="features">
        <h2>What you can do</h2>
        <div class="feature-grid">
            <article class="feature"><div class="feature-icon">✚</div><h3>Register</h3><p>Add your details to the donor list.</p><a href="register.php">Register now →</a></article>
            <article class="feature"><div class="feature-icon">⌕</div><h3>Search</h3><p>Find donors by blood group and city.</p><a href="search.php">Search donors →</a></article>
            <article class="feature"><div class="feature-icon">☷</div><h3>View donors</h3><p>See the registered donor directory.</p><a href="view.php">View list →</a></article>
        </div>
    </section>
</main>
<footer>BloodConnect · College Web Technology Mini Project</footer>
</body>
</html>