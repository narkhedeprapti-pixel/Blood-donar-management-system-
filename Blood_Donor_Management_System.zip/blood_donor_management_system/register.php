<?php
include "db.php";
$message = "";
$messageType = "success";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $age = filter_var($_POST["age"] ?? "", FILTER_VALIDATE_INT);
    $blood = $_POST["blood_group"] ?? "";
    $phone = trim($_POST["phone"] ?? "");
    $city = trim($_POST["city"] ?? "");
    $allowedGroups = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];

    if ($name === "" || !$age || $age < 18 || $age > 65 ||
        !in_array($blood, $allowedGroups, true) ||
        !preg_match('/^[0-9+\-\s]{10,15}$/', $phone) || $city === "") {
        $message = "Please enter valid details. Donor age must be between 18 and 65.";
        $messageType = "error";
    } else {
        $stmt = $conn->prepare("INSERT INTO donors (name, age, blood_group, phone, city) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sisss", $name, $age, $blood, $phone, $city);
        if ($stmt->execute()) {
            $message = "Donor registered successfully!";
        } else {
            $message = "Could not save donor details. Please try again.";
            $messageType = "error";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Donor Registration</title><link rel="stylesheet" href="style.css"><script src="script.js" defer></script>
</head>
<body>
<header class="navbar"><a class="brand" href="index.php">❤️ BloodConnect</a><nav><a href="index.php">Home</a><a href="register.php">Register</a><a href="view.php">View Donors</a><a href="search.php">Search Donor</a></nav></header>
<main class="page-wrap">
    <div class="page-heading"><p class="eyebrow">JOIN OUR DONOR COMMUNITY</p><h1>Donor Registration</h1><p>Fill in your details to join the donor directory.</p></div>
    <section class="form-card">
        <?php if ($message): ?><div class="alert <?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <form method="POST" id="donorForm" onsubmit="return validateDonorForm()">
            <label>Full name<input type="text" name="name" maxlength="100" placeholder="Enter your full name" required></label>
            <div class="form-row">
                <label>Age<input type="number" name="age" min="18" max="65" placeholder="18–65" required></label>
                <label>Blood group<select name="blood_group" required><option value="">Select group</option><?php foreach (["A+","A-","B+","B-","O+","O-","AB+","AB-"] as $g): ?><option value="<?php echo $g; ?>"><?php echo $g; ?></option><?php endforeach; ?></select></label>
            </div>
            <label>Phone number<input type="tel" name="phone" maxlength="15" placeholder="Enter phone number" required></label>
            <label>City<input type="text" name="city" maxlength="80" placeholder="Enter your city" required></label>
            <p class="small-note">By registering, you agree to share these details with people searching for donors. Please do not enter someone else's details without permission.</p>
            <button class="btn full" type="submit">Register Donor</button>
        </form>
    </section>
</main>
<footer>BloodConnect · College Web Technology Mini Project</footer>
</body></html>