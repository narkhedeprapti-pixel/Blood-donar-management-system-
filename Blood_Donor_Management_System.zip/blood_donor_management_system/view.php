<?php
include "db.php";
$result = $conn->query("SELECT id, name, age, blood_group, phone, city FROM donors ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>View Donors</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="navbar"><a class="brand" href="index.php">❤️ BloodConnect</a><nav><a href="index.php">Home</a><a href="register.php">Register</a><a href="view.php">View Donors</a><a href="search.php">Search Donor</a></nav></header>
<main class="page-wrap wide">
<div class="page-heading"><p class="eyebrow">DONOR DIRECTORY</p><h1>Registered Donors</h1><p>Browse the donors who have registered.</p></div>
<div class="table-card">
<?php if ($result && $result->num_rows > 0): ?>
<div class="table-scroll"><table><thead><tr><th>Name</th><th>Age</th><th>Blood Group</th><th>Phone</th><th>City</th></tr></thead><tbody>
<?php while ($row = $result->fetch_assoc()): ?><tr><td><?php echo htmlspecialchars($row["name"]); ?></td><td><?php echo (int)$row["age"]; ?></td><td><span class="blood-badge"><?php echo htmlspecialchars($row["blood_group"]); ?></span></td><td><?php echo htmlspecialchars($row["phone"]); ?></td><td><?php echo htmlspecialchars($row["city"]); ?></td></tr><?php endwhile; ?>
</tbody></table></div>
<?php else: ?><div class="empty"><h3>No donors registered yet</h3><p>Be the first to join the donor directory.</p><a class="btn" href="register.php">Register Donor</a></div><?php endif; ?>
</div>
</main><footer>BloodConnect · College Web Technology Mini Project</footer></body></html>