<?php
include "db.php";
$rows = [];
$searched = false;
$blood = $_GET["blood_group"] ?? "";
$city = trim($_GET["city"] ?? "");
$allowedGroups = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];

if (isset($_GET["search"])) {
    $searched = true;
    if (in_array($blood, $allowedGroups, true)) {
        $likeCity = "%" . $city . "%";
        $stmt = $conn->prepare("SELECT name, age, blood_group, phone, city FROM donors WHERE blood_group = ? AND city LIKE ? ORDER BY name");
        $stmt->bind_param("ss", $blood, $likeCity);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Search Donor</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="navbar"><a class="brand" href="index.php">❤️ BloodConnect</a><nav><a href="index.php">Home</a><a href="register.php">Register</a><a href="view.php">View Donors</a><a href="search.php">Search Donor</a></nav></header>
<main class="page-wrap">
<div class="page-heading"><p class="eyebrow">FIND A DONOR</p><h1>Search Blood Donors</h1><p>Choose a blood group and optionally enter a city.</p></div>
<section class="form-card">
<form method="GET">
<label>Blood group<select name="blood_group" required><option value="">Select group</option><?php foreach (["A+","A-","B+","B-","O+","O-","AB+","AB-"] as $g): ?><option value="<?php echo $g; ?>" <?php echo $blood === $g ? "selected" : ""; ?>><?php echo $g; ?></option><?php endforeach; ?></select></label>
<label>City (optional)<input type="text" name="city" value="<?php echo htmlspecialchars($city); ?>" placeholder="Enter city"></label>
<button class="btn full" type="submit" name="search" value="1">Search Donors</button>
</form>
</section>
<?php if ($searched): ?>
<section class="results">
<h2>Search Results</h2>
<?php if ($rows): ?><div class="table-card table-scroll"><table><thead><tr><th>Name</th><th>Blood Group</th><th>Age</th><th>Phone</th><th>City</th></tr></thead><tbody><?php foreach ($rows as $r): ?><tr><td><?php echo htmlspecialchars($r["name"]); ?></td><td><span class="blood-badge"><?php echo htmlspecialchars($r["blood_group"]); ?></span></td><td><?php echo (int)$r["age"]; ?></td><td><?php echo htmlspecialchars($r["phone"]); ?></td><td><?php echo htmlspecialchars($r["city"]); ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="alert">No matching donors found. Try another city or blood group.</div><?php endif; ?>
</section>
<?php endif; ?>
</main><footer>BloodConnect · College Web Technology Mini Project</footer></body></html>