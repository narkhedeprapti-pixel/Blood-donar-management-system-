CREATE DATABASE IF NOT EXISTS bloodbank
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE bloodbank;

CREATE TABLE IF NOT EXISTS donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    blood_group VARCHAR(3) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    city VARCHAR(80) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional sample records for testing:
INSERT INTO donors (name, age, blood_group, phone, city) VALUES
('Aarav Sharma', 24, 'A+', '9876543210', 'Pune'),
('Neha Patil', 22, 'O+', '9876501234', 'Pune'),
('Rohan Deshmukh', 28, 'B-', '9876512345', 'Mumbai');
