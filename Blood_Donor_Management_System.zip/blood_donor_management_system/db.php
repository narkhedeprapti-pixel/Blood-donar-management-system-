<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "bloodbank");
if ($conn->connect_error) {
    die("Database connection failed. Check XAMPP MySQL settings.");
}
$conn->set_charset("utf8mb4");
?>