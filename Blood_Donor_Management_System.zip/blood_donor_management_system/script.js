function validateDonorForm() {
    const form = document.getElementById("donorForm");
    if (!form) return true;

    const age = Number(form.elements["age"].value);
    const phone = form.elements["phone"].value.trim();

    if (age < 18 || age > 65) {
        alert("Donor age must be between 18 and 65.");
        return false;
    }

    if (!/^[0-9+\-\s]{10,15}$/.test(phone)) {
        alert("Please enter a valid phone number (10 to 15 characters).");
        return false;
    }

    return true;
}
